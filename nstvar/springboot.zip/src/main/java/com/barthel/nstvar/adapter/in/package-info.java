/**
 * Inbound adapters such as web controllers.
 */
package com.barthel.nstvar.adapter.in;
