/**
 * Data transfer objects for web layer.
 */
package com.barthel.nstvar.adapter.in.web.dto;
