/**
 * Web-related inbound adapters.
 */
package com.barthel.nstvar.adapter.in.web;
