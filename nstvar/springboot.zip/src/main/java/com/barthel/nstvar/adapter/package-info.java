/**
 * Adapter layer containing inbound and outbound interfaces.
 */
package com.barthel.nstvar.adapter;
