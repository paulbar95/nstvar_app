/**
 * Application layer containing use cases.
 */
package com.barthel.nstvar.application;
