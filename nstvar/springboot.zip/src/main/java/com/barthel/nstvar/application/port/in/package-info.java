/**
 * Interfaces for incoming application ports.
 */
package com.barthel.nstvar.application.port.in;
