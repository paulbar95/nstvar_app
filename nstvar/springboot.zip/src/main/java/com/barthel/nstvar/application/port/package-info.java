/**
 * Port interfaces for the application layer.
 */
package com.barthel.nstvar.application.port;
