/**
 * Implementations of the application use cases.
 */
package com.barthel.nstvar.application.service;
