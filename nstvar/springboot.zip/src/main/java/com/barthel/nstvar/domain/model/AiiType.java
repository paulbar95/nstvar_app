package com.barthel.nstvar.domain.model;

/**
 * Enumeration of Anthropogenic Impact Index types.
 */
public enum AiiType {
    PM25 // future values: WATER, BIODIVERSITY, SOIL, HABITAT
}
