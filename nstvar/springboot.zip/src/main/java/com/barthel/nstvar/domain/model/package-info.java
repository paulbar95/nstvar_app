/**
 * Domain model classes.
 */
package com.barthel.nstvar.domain.model;
