/**
 * Domain model root package.
 */
package com.barthel.nstvar.domain;
