/**
 * Application configuration classes.
 */
package com.barthel.nstvar.infrastructure.config;
