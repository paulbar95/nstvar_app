/**
 * Custom exception classes.
 */
package com.barthel.nstvar.infrastructure.exception;
