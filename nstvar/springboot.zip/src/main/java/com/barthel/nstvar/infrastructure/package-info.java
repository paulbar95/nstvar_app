/**
 * Technical infrastructure layer.
 */
package com.barthel.nstvar.infrastructure;
